import { Component } from '@angular/core';
@Component({
    selector:"success-alert",
    template:`<h3 class="success-msg"></h3>`,
    styles:[`.success-msg{
            color:green;
    }`]
})
export class SuccessAlert {

}