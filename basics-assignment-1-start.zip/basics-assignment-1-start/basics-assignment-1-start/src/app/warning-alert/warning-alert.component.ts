import { Component } from '@angular/core';

@Component({
    selector:"warning-alert",
    templateUrl:"./warning-alert.component.html",
    styles:[`
        .warn-msg {
            color:red;
        }
    `]
})
export class WarningAlert {

}